# VLESS Gratis Indonesia & Singapore

Website statis penyedia akun VLESS gratis dengan server dari Indonesia & Singapore. Tidak memerlukan VPS.

## Cara Deploy (Gratis)

1. Fork repo ini ke GitHub
2. Buka [Cloudflare Pages](https://pages.cloudflare.com/)
3. Buat proyek baru dari repo ini
4. Output folder: `public`
5. Selesai! Website aktif dengan domain Cloudflare.

## Teknologi:
- Cloudflare Pages (hosting)
- HTML + JS murni
- Server dummy (id1 / sg1.vlessfree.site)